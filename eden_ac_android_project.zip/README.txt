Eden AC Android App (WebView)
=============================

ملفات جاهزة للفتح بـ Android Studio:
1) افتح Android Studio > Open > اختر مجلد المشروع.
2) انتظر مزامنة Gradle.
3) من القائمة: Build > Build APK(s).
4) سيظهر الـ APK في: app/build/outputs/apk/debug/app-debug.apk
5) انسخه إلى هاتفك وثبّت (فعّل "Install from unknown sources").

• التطبيق يعمل بالكامل أوفلاين ويخزّن البيانات محلياً.
• يمكنك تعديل محتوى التطبيق داخل: app/src/main/assets/index.html